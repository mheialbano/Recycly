package utility;

public class Input {
	public static boolean isEmpty(String input) {
		if(input==null||input.equals(null))
			return true;
		else
			return false;
	}
}
